package br.ufrn.imd.util;

public interface SelectOptions {
    int getId();
    String getChave();
    String getValor();
}
