package br.ufrn.imd.dao;

import br.ufrn.imd.dominio.Endereco;

public interface EnderecoDao extends EntidadeDao<Endereco> {
}
