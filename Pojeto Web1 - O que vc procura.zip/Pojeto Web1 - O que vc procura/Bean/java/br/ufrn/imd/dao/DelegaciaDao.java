package br.ufrn.imd.dao;

import br.ufrn.imd.dominio.Delegacia;

public interface DelegaciaDao extends EntidadeDao<Delegacia>{
}
