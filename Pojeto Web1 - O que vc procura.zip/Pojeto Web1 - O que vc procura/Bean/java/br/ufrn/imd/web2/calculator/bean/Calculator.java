/**
 * 
 */
package br.ufrn.imd.web2.calculator.bean;

/**
 * @author kaduardo
 *
 */
public interface Calculator {
	public int add(int... arguments);
}
