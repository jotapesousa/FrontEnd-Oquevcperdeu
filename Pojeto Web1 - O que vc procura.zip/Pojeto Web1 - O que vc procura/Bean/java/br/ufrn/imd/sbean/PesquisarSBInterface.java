package br.ufrn.imd.sbean;

import br.ufrn.imd.dominio.TipoDocumento;

import java.util.List;

public interface PesquisarSBInterface {

    public List pesquisar(String identificador);

}
