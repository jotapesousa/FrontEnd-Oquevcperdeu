package br.ufrn.imd.sbean;

import br.ufrn.imd.dominio.Usuario;

public interface LoginSBInterface {

    Usuario validarUsuario(Usuario usuario);
}
