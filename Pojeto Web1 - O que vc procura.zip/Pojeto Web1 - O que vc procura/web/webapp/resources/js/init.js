$(document).ready(function(){
    $('select').formSelect();

    $('.sidenav').sidenav();

    $('.dropdown-trigger').dropdown();

    $('.collapsible').collapsible();
});